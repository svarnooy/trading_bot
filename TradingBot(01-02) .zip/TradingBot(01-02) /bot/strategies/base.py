# bot/strategies/base.py
from abc import ABC, abstractmethod
import pandas as pd
import numpy as np
from typing import List, Tuple

class BaseStrategy(ABC):
    def __init__(self, cfg):
        self.cfg = cfg
        self.df_higher = None  # для MTF

    @abstractmethod
    def generate_signals(self, df: pd.DataFrame) -> np.ndarray:
        pass

    def ema(self, df: pd.DataFrame, period: int) -> np.ndarray:
        return df['close'].ewm(span=period, adjust=False).mean().to_numpy()

    def atr(self, df: pd.DataFrame) -> np.ndarray:
        h, l, c = df['high'], df['low'], df['close']
        tr = pd.concat([h - l, (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)
        return tr.rolling(self.cfg.atr_period).mean().to_numpy()

    def find_key_levels(self, df: pd.DataFrame, lookback: int = 100) -> Tuple[List[float], List[float]]:
        """Находит уровни поддержки и сопротивления — даже в тренде"""
        highs = df['high'].iloc[-lookback:].to_numpy()
        lows = df['low'].iloc[-lookback:].to_numpy()
        
        # === 1. Локальные экстремумы (как раньше) ===
        local_resistances = []
        local_supports = []
        for i in range(1, len(highs)-1):
            if highs[i] > highs[i-1] and highs[i] > highs[i+1]:
                local_resistances.append(highs[i])
            if lows[i] < lows[i-1] and lows[i] < lows[i+1]:
                local_supports.append(lows[i])

        # === 2. Уровни через кластеризацию цен (плотность) ===
        price_min = lows.min()
        price_max = highs.max()
        if price_max <= price_min:
            price_bins = np.array([price_min, price_max])
        else:
            price_bins = np.linspace(price_min, price_max, num=25)
        
        hist_high, _ = np.histogram(highs, bins=price_bins)
        hist_low, _ = np.histogram(lows, bins=price_bins)
        
        # Берём зоны с высокой плотностью (верхние 70%)
        threshold_high = np.percentile(hist_high, 70)
        threshold_low = np.percentile(hist_low, 70)
        
        resistance_zones = price_bins[:-1][hist_high > threshold_high]
        support_zones = price_bins[:-1][hist_low > threshold_low]

        # === 3. Объединяем и сортируем ===
        resistances = sorted(set(list(resistance_zones) + local_resistances))
        supports = sorted(set(list(support_zones) + local_supports))

        # Ограничиваем до 10 ближайших
        if len(resistances) > 0:
            resistances = resistances[-10:]
        if len(supports) > 0:
            supports = supports[:10]

        return supports, resistances

    def find_nearest_liquidity_zone(self, price: float, levels: List[float], direction: str = "up") -> float:
        """Находит ближайшую зону ликвидности"""
        if direction == "up":
            higher_levels = [l for l in levels if l > price]
            return min(higher_levels) if higher_levels else price * 1.05
        else:
            lower_levels = [l for l in levels if l < price]
            return max(lower_levels) if lower_levels else price * 0.95

    def find_dynamic_sl(self, df: pd.DataFrame, direction: str = "long") -> float:
        """Находит динамический стоп-лосс за последним экстремумом"""
        recent = df.tail(20)
        if direction == "long":
            return recent['low'].min() * 0.998
        else:
            return recent['high'].max() * 1.002

    def is_near_level(self, price: float, levels: List[float], buffer: float = 0.001) -> bool:
        return any(abs(price - level) / level < buffer for level in levels)

    def detect_orderflow(self, df: pd.DataFrame, i: int) -> int:
        open_p = df['open'].iloc[i]
        close_p = df['close'].iloc[i]
        high_p = df['high'].iloc[i]
        low_p = df['low'].iloc[i]
        volume = df['volume'].iloc[i]
        avg_vol = df['volume'].iloc[max(0, i-20):i].mean() or volume

        total_range = high_p - low_p
        if total_range == 0:
            return 0

        body = close_p - open_p
        body_ratio = abs(body) / total_range
        vol_ratio = volume / avg_vol

        # Минимальные условия для входа в тренде
        if body > 0 and body_ratio > 0.2 and vol_ratio > 1.0:
            return 1
        if body < 0 and body_ratio > 0.2 and vol_ratio > 1.0:
            return -1
        return 0