# bot/strategies/breakout.py
import numpy as np
import pandas as pd
from .base import BaseStrategy

class BreakoutStrategy(BaseStrategy):
    def generate_signals(self, df: pd.DataFrame) -> np.ndarray:
        if len(df) < 20:
            return np.zeros(len(df))
            
        close = df['close'].to_numpy()
        high = df['high'].to_numpy()
        low = df['low'].to_numpy()
        
        signals = np.zeros(len(close))
        
        for i in range(20, len(close)):
            # Диапазон за последние 20 свечей
            range_high = np.max(high[i-20:i])
            range_low = np.min(low[i-20:i])
            
            # Пробой вверх
            if close[i] > range_high * 1.01:
                signals[i] = 1
            # Пробой вниз
            elif close[i] < range_low * 0.99:
                signals[i] = -1
                
        return signals