# bot/strategies/countertrend.py
import numpy as np
import pandas as pd
from .base import BaseStrategy

class CounterTrendStrategy(BaseStrategy):
    def generate_signals(self, df: pd.DataFrame) -> np.ndarray:
        if len(df) < 15:
            return np.zeros(len(df))
            
        close = df['close'].to_numpy()
        rsi = self.calculate_rsi(df, 14)
        
        signals = np.zeros(len(close))
        
        for i in range(15, len(close)):
            # Перепроданность
            if rsi[i] < 35:
                signals[i] = 1
            # Перекупленность
            elif rsi[i] > 65:
                signals[i] = -1
                
        return signals
    
    def calculate_rsi(self, df: pd.DataFrame, period: int = 14) -> np.ndarray:
        close = df['close'].to_numpy()
        delta = np.diff(close)
        gain = np.where(delta > 0, delta, 0)
        loss = np.where(delta < 0, -delta, 0)
        
        avg_gain = np.zeros(len(close))
        avg_loss = np.zeros(len(close))
        
        if len(gain) >= period:
            avg_gain[period] = np.mean(gain[:period])
            avg_loss[period] = np.mean(loss[:period])
            
            for i in range(period + 1, len(close)):
                avg_gain[i] = (avg_gain[i-1] * (period - 1) + gain[i-1]) / period
                avg_loss[i] = (avg_loss[i-1] * (period - 1) + loss[i-1]) / period
        
        rs = np.divide(avg_gain, avg_loss, out=np.zeros_like(avg_gain), where=avg_loss!=0)
        rsi = 100 - (100 / (1 + rs))
        return rsi