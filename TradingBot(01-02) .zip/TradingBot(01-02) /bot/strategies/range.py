# bot/strategies/range.py
import numpy as np
import pandas as pd
from .base import BaseStrategy

class RangeStrategy(BaseStrategy):
    def generate_signals(self, df: pd.DataFrame) -> np.ndarray:
        if len(df) < 30:
            return np.zeros(len(df))
            
        close = df['close'].to_numpy()
        high = df['high'].to_numpy()
        low = df['low'].to_numpy()
        
        signals = np.zeros(len(close))
        
        # Диапазон за последние 30 свечей (30 дней на 4H)
        recent_high = np.max(high[-30:])
        recent_low = np.min(low[-30:])
        
        for i in range(30, len(close)):
            # Лонг при отскоке от поддержки
            if close[i] < recent_low * 1.01 and close[i-1] >= recent_low * 1.01:
                signals[i] = 1
            # Шорт при отскоке от сопротивления  
            elif close[i] > recent_high * 0.99 and close[i-1] <= recent_high * 0.99:
                signals[i] = -1
                
        return signals