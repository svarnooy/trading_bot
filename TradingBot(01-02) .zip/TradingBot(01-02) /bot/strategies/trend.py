# bot/strategies/trend.py
import numpy as np
import pandas as pd
from .base import BaseStrategy

class TrendStrategy(BaseStrategy):
    def generate_signals(self, df: pd.DataFrame) -> np.ndarray:
        """
        Простая трендовая стратегия для 4H
        """
        if len(df) < self.cfg.long_sma_period + 10:
            return np.zeros(len(df))
            
        close = df['close'].to_numpy()
        ema_fast = self.ema(df, self.cfg.short_sma_period)
        ema_slow = self.ema(df, self.cfg.long_sma_period)
        
        signals = np.zeros(len(close))
        
        for i in range(self.cfg.long_sma_period + 1, len(close)):
            # На 4H достаточно простого EMA фильтра
            if ema_fast[i] > ema_slow[i] and close[i] > ema_fast[i]:
                signals[i] = 1
            elif ema_fast[i] < ema_slow[i] and close[i] < ema_fast[i]:
                signals[i] = -1
        
        return signals